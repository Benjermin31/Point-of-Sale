/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package resturant_system;

/**
 *
 * @author BENJERMIN
 */
//Different Jform used to extend a relationship
public class resturant2_system extends Resturant_system 
{
    
}
