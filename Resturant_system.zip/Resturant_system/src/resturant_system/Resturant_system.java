/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//create a different java jform for this code
package resturant_system;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
/**
 *
 * @author BENJERMIN
 */
public class Resturant_system {
    
    public double Chicken_Shawarma_Roll;
    public double Chicken_Tikka_Roll;
    public double Veg_Roll;
    public double Egg_Roll;
    public double Grilled_ChickenF;
    public double Grilled_ChickenH;
    
    public double Arrabian_Pulpy_Juice;
    public double French_Lime_juice;
    public double Fresh_Lime_soda;
    public double Coccum_Juice;
    public double Butter_milk;
    public double Raagi_Milk;
    
    public double Meals;
    public double Drinks;
    public double TotalCost;
    
    public double AllTotalCost;
    
    public double GetAmount()
    {
        Meals = Chicken_Shawarma_Roll + Chicken_Tikka_Roll + Veg_Roll + Egg_Roll +  Grilled_ChickenF + Grilled_ChickenH;
        Drinks =  Arrabian_Pulpy_Juice + French_Lime_juice + Fresh_Lime_soda + Coccum_Juice + Butter_milk + Raagi_Milk;
        TotalCost = Meals + Drinks;
        AllTotalCost = TotalCost;
        return AllTotalCost;  //Drinks;
    }
    private JFrame frame;
    
    public void iResturant_system()
        {
            frame = new JFrame("Exit");
                if (JOptionPane.showConfirmDialog(frame, "Confirm if you want to exit system","Resturant_system",
                     JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION){ 
                    System.exit(0);
                }
        }
    
//=======================================Price=========================================

 public double pChicken_Shawarma_Roll = 18000;
    public double pChicken_Tikka_Roll = 16000;
    public double pVeg_Roll = 10000;
    public double pEgg_Roll = 6000;
    public double pGrilled_ChickenF = 24000;
    public double pGrilled_ChickenH = 20000;
    
    public double pArrabian_Pulpy_Juice = 5000;
    public double pFrench_Lime_juice = 9000;
    public double pFresh_Lime_soda = 3500;
    public double pCoccum_Juice = 4000;
    public double pButter_milk = 10000;
    public double pRaagi_Milk = 8000;
    //+====================================================================================
    
    public double mcTax = 1.0;
    
    public Double cFindTax(double cAmount)
    {
        double FindTax = cAmount - (cAmount * mcTax);
        return FindTax;
    }
    //+====================================================================================
    //The above code represents all the products of the resturant and how to total up..............
}
    

    
   
